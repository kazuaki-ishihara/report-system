<?php
/** @var array $user */
/** @var string $tab */
/** @var string $stage */
/** @var array $errors */
$full = $stage === 'full' && (int) $user['must_change_password'] !== 1;
?>
<section class="card">
  <h1>アカウント設定</h1>
  <?php if ($full): ?>
  <nav class="tabs">
    <a href="<?= h(url('/account.php?tab=totp')) ?>" class="<?= $tab === 'totp' ? 'active' : '' ?>">2 段階認証</a>
    <a href="<?= h(url('/account.php?tab=codes')) ?>" class="<?= $tab === 'codes' ? 'active' : '' ?>">予備のコード</a>
    <a href="<?= h(url('/account.php?tab=devices')) ?>" class="<?= $tab === 'devices' ? 'active' : '' ?>">端末</a>
    <a href="<?= h(url('/account.php?tab=password')) ?>" class="<?= $tab === 'password' ? 'active' : '' ?>">パスワード</a>
    <a href="<?= h(url('/account.php?tab=theme')) ?>" class="<?= $tab === 'theme' ? 'active' : '' ?>">表示</a>
  </nav>
  <?php endif; ?>

  <?php foreach ($errors as $e): ?>
    <div class="flash flash-error" role="alert"><?= h_lines($e) ?></div>
  <?php endforeach; ?>

  <?php if ($tab === 'totp'): ?>
    <?php if ($settingUp): ?>
      <h2>2 段階認証の設定</h2>
      <?php if ($stage === 'setup'): ?>
        <p>はじめてのログインです。安全のため、2 段階認証を設定してください。設定が終わるまで、ほかの画面は使えません。</p>
      <?php endif; ?>
      <div class="setup-guide">
        <p><strong>スマートフォンを用意してください。</strong>2 段階認証では、ログインのたびにスマートフォンの認証アプリ（Google Authenticator・Microsoft Authenticator など。無料）に出る 6 桁の数字を入れます。先に、App Store または Google Play から認証アプリを入れてください。</p>
        <details class="authenticator-apps">
          <summary>使える認証アプリ</summary>
          <p class="note">「時間ベース」の 6 桁のコードを出すアプリなら使えます。迷ったら、iPhone・Android のどちらでも同じ名前で入れられる Google Authenticator か Microsoft Authenticator を選んでください。</p>
          <ul class="app-list">
            <li><strong>Google Authenticator</strong><span>iPhone・Android／無料</span></li>
            <li><strong>Microsoft Authenticator</strong><span>iPhone・Android／無料。Microsoft のアカウントがなくても使える</span></li>
            <li><strong>IIJ SmartKey</strong><span>iPhone・Android／無料。画面が日本語</span></li>
            <li><strong>Authy</strong><span>iPhone・Android／無料</span></li>
            <li><strong>iPhone の「パスワード」</strong><span>iPhone だけ／最初から入っている（iOS 18 以降。iOS 15〜17 は「設定」の「パスワード」）</span></li>
            <li><strong>Aegis</strong><span>Android だけ／無料</span></li>
          </ul>
          <p class="note">SMS でコードを受け取る方式や、ボタンを押して承認するだけの方式には対応していません。</p>
        </details>
        <div class="setup-pc-hint">
          <p><strong>いまは PC で開いています。この設定は、スマートフォンで行うのがおすすめです。</strong>スマートフォンで開くと、ボタン 1 つで認証アプリに登録できます（PC では、32 文字をスマートフォンに手で打つことになります）。</p>
          <ol>
            <li>スマートフォンのブラウザーで、次のアドレスを開きます。<br><span class="secret"><?= h($loginUrl) ?></span></li>
            <li>同じログイン ID とパスワードでログインし、出てきた画面で設定します。</li>
            <li>設定が終わったら、PC でもう一度ログインしてください。</li>
          </ol>
          <p class="note">スマートフォンからこのアドレスを開けないときは、このまま PC で下の手順に進んでください。</p>
        </div>
      </div>
      <ol class="steps">
        <li>スマートフォンに認証アプリ（Google Authenticator・Microsoft Authenticator など）を入れてください。</li>
        <li>下のボタンを押すと、認証アプリに登録されます。<br>
          <a class="button" href="<?= h($totpUri) ?>">認証アプリに登録する</a>
          <p class="note">うまくいかないときは、認証アプリで「セットアップキーを入力」を選び、次の文字を入れます（時間ベース）。</p>
          <p class="secret"><?= h($secretDisplay) ?></p>
        </li>
        <li>認証アプリに表示された 6 桁の数字を入れてください。</li>
      </ol>
      <form method="post" action="<?= h(url('/account.php?tab=totp')) ?>" class="form">
        <?= form_hidden(false) ?>
        <input type="hidden" name="action" value="totp_confirm">
        <label for="code">6 桁のコード</label>
        <input id="code" name="code" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required>
        <label class="check"><input type="checkbox" name="remember" value="1" checked> この端末を <?= (int) cfg('remember_device_days') ?> 日間記憶する</label>
        <button type="submit" class="primary">設定する</button>
      </form>
    <?php else: ?>
      <h2>2 段階認証</h2>
      <p>設定済み（<?= h(display_datetime($user['totp_enabled_at'])) ?>）</p>
      <form method="post" action="<?= h(url('/account.php?tab=totp')) ?>" class="form">
        <?= form_hidden(false) ?>
        <input type="hidden" name="action" value="totp_redo">
        <p class="note">機種変更などで設定し直すときは、今のパスワードを入れてください。</p>
        <label for="current_password_t">今のパスワード</label>
        <input id="current_password_t" name="current_password" type="password" autocomplete="current-password" required>
        <button type="submit">設定し直す</button>
      </form>
    <?php endif; ?>

  <?php elseif ($tab === 'codes'): ?>
    <h2>予備のコード</h2>
    <?php if (is_array($codes)): ?>
      <p>認証アプリが使えないとき（機種変更など）に、1 つにつき 1 回使えます。<strong>この画面を離れると二度と表示されません。</strong>紙に書くなどして保管してください。</p>
      <ul class="codes" id="backup-codes">
        <?php foreach ($codes as $c): ?><li><?= h($c) ?></li><?php endforeach; ?>
      </ul>
      <p>
        <button type="button" class="small copy-text" data-copy-from="backup-codes">予備のコードをコピー</button>
        <span class="copy-result" aria-live="polite"></span>
      </p>
      <p class="note">コピーしたコードは、パスワードの管理アプリなど安全な場所に貼り付けて保管してください。メールやチャットに貼らないでください。</p>
      <?php if ($afterNext !== ''): ?>
        <a class="button primary" href="<?= h(url($afterNext)) ?>">保管しました</a>
      <?php endif; ?>
    <?php else: ?>
      <p>残り <?= (int) $remaining ?> 個</p>
      <form method="post" action="<?= h(url('/account.php?tab=codes')) ?>" class="form" data-confirm="<?= h(msg('予備のコードを作り直します。今のコードは使えなくなります。よろしいですか？')) ?>">
        <?= form_hidden(false) ?>
        <input type="hidden" name="action" value="codes_regen">
        <label for="current_password_c">今のパスワード</label>
        <input id="current_password_c" name="current_password" type="password" autocomplete="current-password" required>
        <button type="submit">予備のコードを作り直す</button>
      </form>
    <?php endif; ?>

  <?php elseif ($tab === 'devices'): ?>
    <h2>記憶した端末</h2>
    <?php if (!$devices): ?>
      <p>記憶した端末はありません。</p>
    <?php else: ?>
      <ul class="list">
        <?php foreach ($devices as $d): ?>
        <li>
          <span><?= h($d['label']) ?><?= ((int) $d['id'] === $currentDeviceId) ? '（この端末）' : '' ?></span>
          <span class="note">最後に使用 <?= h(display_date($d['last_used_at'])) ?> / 期限 <?= h(display_date($d['expires_at'])) ?></span>
          <form method="post" action="<?= h(url('/account.php?tab=devices')) ?>" class="inline">
            <?= form_hidden(false) ?>
            <input type="hidden" name="action" value="device_revoke">
            <input type="hidden" name="device_id" value="<?= (int) $d['id'] ?>">
            <button type="submit">解除</button>
          </form>
        </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
    <form method="post" action="<?= h(url('/account.php?tab=devices')) ?>" class="form" data-confirm="<?= h(msg('すべての端末からログアウトします。この端末もログアウトします。よろしいですか？')) ?>">
      <?= form_hidden(false) ?>
      <input type="hidden" name="action" value="logout_all">
      <button type="submit" class="danger">すべての端末からログアウト</button>
    </form>
    <p class="note">スマートフォンをなくしたときに使ってください。</p>

  <?php elseif ($tab === 'password'): ?>
    <h2>パスワードの変更</h2>
    <?php if ((int) $user['must_change_password'] === 1): ?>
      <p>仮のパスワードでログインしています。新しいパスワードを決めてください。</p>
    <?php endif; ?>
    <form method="post" action="<?= h(url('/account.php?tab=password')) ?>" class="form">
      <?= form_hidden(false) ?>
      <input type="hidden" name="action" value="password_change">
      <?php if ((int) $user['must_change_password'] !== 1): ?>
        <label for="current_password_p">今のパスワード</label>
        <input id="current_password_p" name="current_password" type="password" autocomplete="current-password" required>
      <?php endif; ?>
      <label for="new_password">新しいパスワード（<?= (int) cfg('password_min_length') ?> 文字以上）</label>
      <div class="password-field">
        <input id="new_password" name="new_password" type="password" autocomplete="new-password" maxlength="200" required>
        <button type="button" class="toggle-password" data-target="new_password">表示</button>
      </div>
      <div class="password-tools">
        <button type="button" class="small generate-password" data-target="new_password" data-confirm-target="new_password_confirm">自動で作る</button>
        <button type="button" class="small copy-text" data-copy-from="new_password">コピー</button>
        <span class="note copy-result" aria-live="polite"></span>
      </div>
      <label for="new_password_confirm">新しいパスワード（確認）</label>
      <input id="new_password_confirm" name="new_password_confirm" type="password" autocomplete="new-password" maxlength="200" required>
      <button type="submit" class="primary">変更する</button>
    </form>

  <?php elseif ($tab === 'theme'): $currentThemeName = (string) ($user['ui_theme'] ?? 'auto'); /** @var array{base: string, accent: string, background: string} $customColors */ ?>
    <h2>画面のテーマ</h2>
    <p class="note">画面の配色を選べます。変わるのは自分の画面だけです（ほかの人の画面は変わりません）。注意やエラーを表す色の意味は、どのテーマでも同じです。</p>
    <form method="post" action="<?= h(url('/account.php?tab=theme')) ?>" class="form theme-form">
      <?= form_hidden(false) ?>
      <input type="hidden" name="action" value="theme_save">
      <div class="theme-choice-list">
        <?php foreach (UI_THEMES as $themeName => $themeLabel): ?>
          <label class="theme-choice">
            <input type="radio" name="ui_theme" value="<?= h($themeName) ?>" <?= $themeName === $currentThemeName ? 'checked' : '' ?>>
            <span class="theme-swatch theme-swatch-<?= h($themeName) ?>" aria-hidden="true"><span></span><span></span><span></span></span>
            <span class="theme-choice-text"><span class="theme-choice-name"><?= h($themeLabel) ?></span><span class="theme-color-names"><?= h(UI_THEME_COLOR_NAMES[$themeName] ?? '') ?></span></span>
          </label>
        <?php endforeach; ?>
      </div>
      <fieldset class="sub custom-colors" id="custom-colors">
        <legend>自分の色（「自分の色」を選んだときに使います）</legend>
        <p class="note">土台と、強調の色（ボタン・見出し・リンク）、背景の色を選べます。注意・エラー・状態の札の色は変わりません（意味が変わらないように）。文字が読みにくくなる組み合わせのときは注意を出します（保存はできます）。</p>
        <div class="choices">
          <label class="choice"><input type="radio" name="custom_base" value="light" <?= $customColors['base'] !== 'dark' ? 'checked' : '' ?>> 明るい土台（白い面・黒い文字）</label>
          <label class="choice"><input type="radio" name="custom_base" value="dark" <?= $customColors['base'] === 'dark' ? 'checked' : '' ?>> 暗い土台（黒い面・白い文字）</label>
        </div>
        <div class="custom-color-inputs">
          <label for="custom_accent">強調の色 <input id="custom_accent" name="custom_accent" type="color" value="<?= h($customColors['accent']) ?>"></label>
          <label for="custom_background">背景の色 <input id="custom_background" name="custom_background" type="color" value="<?= h($customColors['background']) ?>"></label>
        </div>
        <div class="custom-color-preview" aria-hidden="true">
          <div class="custom-color-preview-card">
            <strong class="custom-color-preview-heading">見本の見出し</strong>
            <p>本文の文字です。<a href="#custom-colors">リンク</a></p>
            <span class="custom-color-preview-button">ボタン</span>
          </div>
        </div>
        <p class="note custom-color-check" aria-live="polite"></p>
      </fieldset>
      <button type="submit" class="primary">このテーマにする</button>
    </form>
  <?php endif; ?>
</section>
